const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Deposit = require('../models/Deposit');
const Withdraw = require('../models/Withdraw');
const { protect, adminOnly } = require('../middleware/auth');

// All admin routes require auth + admin role
router.use(protect, adminOnly);

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalDeposits = await Deposit.aggregate([{ $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }]);
    const totalWithdrawals = await Withdraw.aggregate([{ $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }]);
    const pendingDeposits = await Deposit.countDocuments({ status: 'pending' });
    const pendingWithdrawals = await Withdraw.countDocuments({ status: 'pending' });
    const totalUsdHeld = await User.aggregate([{ $group: { _id: null, total: { $sum: '$usdBalance' } } }]);

    res.json({
      totalUsers,
      totalDeposits: totalDeposits[0] || { total: 0, count: 0 },
      totalWithdrawals: totalWithdrawals[0] || { total: 0, count: 0 },
      pendingDeposits,
      pendingWithdrawals,
      totalUsdHeld: totalUsdHeld[0]?.total || 0
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find({ role: 'user' }).select('-password').sort({ createdAt: -1 });
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// PATCH /api/admin/users/:id/balance
router.patch('/users/:id/balance', [
  body('usdBalance').isFloat({ min: 0 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { usdBalance: req.body.usdBalance },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update balance' });
  }
});

// PATCH /api/admin/users/:id/status
router.patch('/users/:id/status', [
  body('isActive').isBoolean()
], async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive: req.body.isActive },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// GET /api/admin/deposits
router.get('/deposits', async (req, res) => {
  try {
    const deposits = await Deposit.find().populate('user', 'firstName lastName email').sort({ createdAt: -1 });
    res.json({ deposits });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch deposits' });
  }
});

// PATCH /api/admin/deposits/:id
router.patch('/deposits/:id', [
  body('status').isIn(['approved', 'rejected']),
  body('adminNote').optional().trim()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  try {
    const deposit = await Deposit.findById(req.params.id);
    if (!deposit) return res.status(404).json({ error: 'Deposit not found' });
    if (deposit.status !== 'pending') return res.status(400).json({ error: 'Deposit already processed' });

    deposit.status = req.body.status;
    deposit.adminNote = req.body.adminNote;
    deposit.updatedAt = new Date();
    await deposit.save();

    if (req.body.status === 'approved') {
      const user = await User.findById(deposit.user);
      user.usdBalance += deposit.amount;
      user.transactions.push({
        type: 'deposit',
        amount: deposit.amount,
        status: 'approved',
        note: 'Deposit approved by admin'
      });
      await user.save();
    }

    res.json({ deposit });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update deposit' });
  }
});

// GET /api/admin/withdrawals
router.get('/withdrawals', async (req, res) => {
  try {
    const withdrawals = await Withdraw.find().populate('user', 'firstName lastName email').sort({ createdAt: -1 });
    res.json({ withdrawals });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch withdrawals' });
  }
});

// PATCH /api/admin/withdrawals/:id
router.patch('/withdrawals/:id', [
  body('status').isIn(['approved', 'rejected']),
  body('adminNote').optional().trim()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  try {
    const withdrawal = await Withdraw.findById(req.params.id);
    if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found' });
    if (withdrawal.status !== 'pending') return res.status(400).json({ error: 'Withdrawal already processed' });

    withdrawal.status = req.body.status;
    withdrawal.adminNote = req.body.adminNote;
    withdrawal.updatedAt = new Date();
    await withdrawal.save();

    // If rejected, refund the amount
    if (req.body.status === 'rejected') {
      const user = await User.findById(withdrawal.user);
      user.usdBalance += withdrawal.amount;
      user.transactions.push({
        type: 'deposit',
        amount: withdrawal.amount,
        status: 'completed',
        note: 'Withdrawal rejected - amount refunded'
      });
      await user.save();
    }

    res.json({ withdrawal });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update withdrawal' });
  }
});

module.exports = router;
