# NexusTrade — Full-Stack Crypto Broker

A premium crypto trading platform with real-time prices, secure auth, and admin panel.

---

## 🗂️ Project Structure

```
cryptobroker/
├── backend/
│   ├── server.js              # Express app entry
│   ├── config/
│   │   └── db.js              # MongoDB connection
│   ├── models/
│   │   ├── User.js            # User + wallet + transactions
│   │   ├── Deposit.js         # Deposit requests
│   │   └── Withdraw.js        # Withdrawal requests
│   ├── routes/
│   │   ├── auth.js            # Register, login, admin login
│   │   ├── user.js            # Profile, transactions
│   │   ├── trade.js           # Buy/sell
│   │   ├── deposit.js         # Deposit requests
│   │   ├── withdraw.js        # Withdrawal requests
│   │   └── admin.js           # Admin panel routes
│   ├── middleware/
│   │   └── auth.js            # JWT + admin guard
│   └── .env.example
└── frontend/
    └── cryptobroker-frontend.html  # Full SPA (React-free, pure JS)
```

---

## ⚙️ Backend Setup

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)

### 1. Install dependencies
```bash
cd backend
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your values:
```

```env
PORT=5000
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/cryptobroker
JWT_SECRET=your_very_long_random_secret_here
JWT_EXPIRE=7d
FRONTEND_URL=http://localhost:3000
NODE_ENV=development
```

### 3. Create first admin user
In MongoDB Compass or Atlas, manually insert:
```json
{
  "firstName": "Admin",
  "lastName": "NexusTrade",
  "email": "admin@nexustrade.com",
  "password": "$2b$12$...(bcrypt hash of your password)",
  "role": "admin",
  "usdBalance": 0,
  "wallet": {"BTC": 0, "ETH": 0, "USDT": 0},
  "isActive": true
}
```

Or use this one-time seed script:
```js
// seed-admin.js
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  await User.create({
    firstName: 'Admin', lastName: 'NexusTrade',
    email: 'admin@nexustrade.com',
    password: 'Admin@1234',  // will be hashed by pre-save hook
    role: 'admin', usdBalance: 0,
    wallet: { BTC: 0, ETH: 0, USDT: 0 }, isActive: true
  });
  console.log('Admin created!');
  process.exit(0);
});
```
Run: `node seed-admin.js`

### 4. Start server
```bash
npm run dev   # Development with nodemon
npm start     # Production
```

---

## 🖥️ Frontend Setup

The frontend is a **single HTML file** — no build step needed.

### Option A: Direct Open
Simply open `cryptobroker-frontend.html` in your browser.
> In demo mode (DEMO_MODE = true), it simulates all API calls locally.

### Option B: Connect to real backend
1. Edit line in frontend: `const DEMO_MODE = false;`
2. Edit `const API = 'http://localhost:5000/api';`
3. Serve via any static host (Vercel, Nginx, GitHub Pages)

---

## 🔑 Demo Credentials

In DEMO MODE (default):
- **User:** `demo@nexus.com` / `demo123`
- **Admin:** `admin@nexus.com` / `admin123`

---

## 🌐 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register user |
| POST | /api/auth/login | Login user |
| POST | /api/auth/admin/login | Admin login |
| GET | /api/auth/me | Get current user |

### User
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | /api/user/profile | ✅ | Get profile |
| GET | /api/user/transactions | ✅ | Transaction history |

### Trade
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/trade/buy | ✅ | Buy crypto |
| POST | /api/trade/sell | ✅ | Sell crypto |

### Deposit
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/deposit/request | ✅ | Submit deposit |
| GET | /api/deposit/my | ✅ | My deposits |

### Withdraw
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/withdraw/request | ✅ | Submit withdrawal |
| GET | /api/withdraw/my | ✅ | My withdrawals |

### Admin (admin role required)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/admin/stats | Platform stats |
| GET | /api/admin/users | All users |
| PATCH | /api/admin/users/:id/balance | Edit balance |
| PATCH | /api/admin/users/:id/status | Ban/unban user |
| GET | /api/admin/deposits | All deposits |
| PATCH | /api/admin/deposits/:id | Approve/reject |
| GET | /api/admin/withdrawals | All withdrawals |
| PATCH | /api/admin/withdrawals/:id | Process withdrawal |

---

## 🚀 Deployment

### Backend → Railway / Render

**Railway:**
1. Push backend to GitHub
2. New project → Deploy from GitHub
3. Add env variables in Railway dashboard
4. Auto-deploys on push

**Render:**
1. New Web Service → Connect GitHub
2. Build: `npm install`, Start: `npm start`
3. Add env vars in Render dashboard

### Frontend → Vercel

1. Put the HTML file in a repo
2. `vercel deploy` or connect GitHub to Vercel
3. Set `DEMO_MODE = false` and update API URL

---

## 🔒 Security Features

- **bcryptjs** password hashing (12 rounds)
- **JWT** authentication with expiry
- **express-rate-limit** (100 req/15min, 10 auth/15min)
- **express-validator** input sanitization
- **CORS** whitelist configuration
- **Admin role** guard on all admin routes
- **Input size limit** (10kb JSON body)
- **Balance reservation** on withdrawal (prevents double-spend)

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Vanilla JS SPA, Chart.js, CoinGecko API |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| Prices | CoinGecko (free public API) |
| Deployment | Railway/Render + Vercel |
